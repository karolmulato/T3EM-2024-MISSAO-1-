const caixaprincipal = document.querySelector(".caixa-principal");
const caixapergunta = document.querySelector(".caixa-pergunta");
const caixaaltenativa = document.querySelector(".caixa-altenativa");
const caixaresultado = document.querySelector(".caixa-resultado");
const caixaresultado = document.querySelector(".texto-resultado");
